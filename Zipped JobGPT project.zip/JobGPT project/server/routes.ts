import type { Express } from "express";
import { createServer, type Server } from "http";
import multer from "multer";
import { storage } from "./storage";
import { 
  analyzeResume, 
  generateCareerRecommendations, 
  generateCareerPath,
  calculateJobMatch 
} from "./lib/gemini";
import { extractTextFromFile } from "./lib/pdfParser";
import { 
  insertResumeSchema, 
  insertSkillSchema, 
  insertCareerPathSchema,
  insertRecommendationSchema 
} from "@shared/schema";

// Configure multer for file uploads
const upload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: 10 * 1024 * 1024, // 10MB limit
  },
  fileFilter: (req, file, cb) => {
    const allowedTypes = [
      'application/pdf',
      'application/msword',
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      'text/plain'
    ];
    
    if (allowedTypes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error('Invalid file type. Only PDF, DOC, DOCX, and TXT files are allowed.'));
    }
  }
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Mock user ID for demo purposes (in production, use proper authentication)
  const DEMO_USER_ID = 1;

  // Create demo user if not exists
  const existingUser = await storage.getUser(DEMO_USER_ID);
  if (!existingUser) {
    await storage.createUser({
      username: "demo_user",
      password: "demo_password",
      email: "demo@careercraft.com",
      firstName: "John",
      lastName: "Doe"
    });
  }

  // Upload and analyze resume
  app.post("/api/resume/upload", upload.single('resume'), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }

      // Extract text from file
      const content = await extractTextFromFile(req.file.buffer, req.file.mimetype);
      
      if (!content || content.length < 50) {
        return res.status(400).json({ message: "Could not extract meaningful content from file" });
      }

      // Save resume to storage
      const resume = await storage.createResume({
        userId: DEMO_USER_ID,
        filename: req.file.originalname,
        content
      });

      // Analyze resume with AI
      const analysis = await analyzeResume(content);
      
      // Update resume with analysis
      const updatedResume = await storage.updateResumeAnalysis(
        resume.id, 
        analysis, 
        analysis.overallScore
      );

      // Save identified skills
      for (const skill of analysis.skillsIdentified) {
        await storage.createSkill({
          userId: DEMO_USER_ID,
          name: skill.name,
          level: skill.level,
          category: skill.category
        });
      }

      // Generate recommendations
      const recommendations = await generateCareerRecommendations(
        analysis,
        "Software Engineer",
        "Senior Software Engineer"
      );

      // Save recommendations
      for (const rec of recommendations) {
        await storage.createRecommendation({
          userId: DEMO_USER_ID,
          type: rec.type,
          title: rec.title,
          description: rec.description,
          priority: rec.priority
        });
      }

      res.json({ 
        resume: updatedResume, 
        analysis,
        recommendations 
      });
    } catch (error) {
      console.error("Resume upload error:", error);
      res.status(500).json({ 
        message: "Failed to process resume", 
        error: error instanceof Error ? error.message : "Unknown error" 
      });
    }
  });

  // Get user resumes
  app.get("/api/resumes", async (req, res) => {
    try {
      const resumes = await storage.getUserResumes(DEMO_USER_ID);
      res.json(resumes);
    } catch (error) {
      console.error("Get resumes error:", error);
      res.status(500).json({ message: "Failed to fetch resumes" });
    }
  });

  // Get latest resume analysis
  app.get("/api/resume/analysis", async (req, res) => {
    try {
      const resumes = await storage.getUserResumes(DEMO_USER_ID);
      const latestResume = resumes.sort((a, b) => 
        new Date(b.uploadedAt!).getTime() - new Date(a.uploadedAt!).getTime()
      )[0];
      
      if (!latestResume || !latestResume.analysis) {
        return res.status(404).json({ message: "No resume analysis found" });
      }

      res.json({
        resume: latestResume,
        analysis: latestResume.analysis
      });
    } catch (error) {
      console.error("Get analysis error:", error);
      res.status(500).json({ message: "Failed to fetch analysis" });
    }
  });

  // Get user skills
  app.get("/api/skills", async (req, res) => {
    try {
      const skills = await storage.getUserSkills(DEMO_USER_ID);
      res.json(skills);
    } catch (error) {
      console.error("Get skills error:", error);
      res.status(500).json({ message: "Failed to fetch skills" });
    }
  });

  // Update skill level
  app.patch("/api/skills/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const { level } = req.body;
      
      if (typeof level !== 'number' || level < 0 || level > 100) {
        return res.status(400).json({ message: "Invalid skill level" });
      }

      const skill = await storage.updateSkillLevel(parseInt(id), level);
      res.json(skill);
    } catch (error) {
      console.error("Update skill error:", error);
      res.status(500).json({ message: "Failed to update skill" });
    }
  });

  // Get all jobs
  app.get("/api/jobs", async (req, res) => {
    try {
      const jobs = await storage.getAllJobs();
      res.json(jobs);
    } catch (error) {
      console.error("Get jobs error:", error);
      res.status(500).json({ message: "Failed to fetch jobs" });
    }
  });

  // Get job matches for user
  app.get("/api/job-matches", async (req, res) => {
    try {
      // Get user skills
      const userSkills = await storage.getUserSkills(DEMO_USER_ID);
      const jobs = await storage.getAllJobs();

      // Calculate matches for each job
      const matches = [];
      for (const job of jobs) {
        const requirements = Array.isArray(job.requirements) ? job.requirements : [];
        const matchResult = await calculateJobMatch(userSkills, requirements);
        
        // Create job match record
        const jobMatch = await storage.createJobMatch({
          userId: DEMO_USER_ID,
          jobId: job.id,
          matchScore: matchResult.score,
          reasons: matchResult.reasons
        });

        matches.push({
          ...jobMatch,
          job
        });
      }

      // Sort by match score descending
      matches.sort((a, b) => b.matchScore - a.matchScore);
      
      res.json(matches.slice(0, 10)); // Return top 10 matches
    } catch (error) {
      console.error("Get job matches error:", error);
      res.status(500).json({ message: "Failed to fetch job matches" });
    }
  });

  // Get or create career path
  app.get("/api/career-path", async (req, res) => {
    try {
      let careerPath = await storage.getUserCareerPath(DEMO_USER_ID);
      
      if (!careerPath) {
        // Generate career path
        const userSkills = await storage.getUserSkills(DEMO_USER_ID);
        const pathData = await generateCareerPath(
          "Software Engineer",
          "Senior Software Engineer",
          userSkills
        );

        careerPath = await storage.createCareerPath({
          userId: DEMO_USER_ID,
          currentPosition: "Software Engineer",
          targetPosition: "Senior Software Engineer",
          steps: pathData.steps,
          timeline: pathData.timeline
        });
      }

      res.json(careerPath);
    } catch (error) {
      console.error("Get career path error:", error);
      res.status(500).json({ message: "Failed to fetch career path" });
    }
  });

  // Update career path progress
  app.patch("/api/career-path/:id/progress", async (req, res) => {
    try {
      const { id } = req.params;
      const { progress } = req.body;
      
      if (typeof progress !== 'number' || progress < 0 || progress > 100) {
        return res.status(400).json({ message: "Invalid progress value" });
      }

      const careerPath = await storage.updateCareerPathProgress(parseInt(id), progress);
      res.json(careerPath);
    } catch (error) {
      console.error("Update career path error:", error);
      res.status(500).json({ message: "Failed to update career path" });
    }
  });

  // Get user recommendations
  app.get("/api/recommendations", async (req, res) => {
    try {
      const recommendations = await storage.getUserRecommendations(DEMO_USER_ID);
      res.json(recommendations);
    } catch (error) {
      console.error("Get recommendations error:", error);
      res.status(500).json({ message: "Failed to fetch recommendations" });
    }
  });

  // Mark recommendation as applied
  app.patch("/api/recommendations/:id/apply", async (req, res) => {
    try {
      const { id } = req.params;
      const recommendation = await storage.markRecommendationApplied(parseInt(id));
      res.json(recommendation);
    } catch (error) {
      console.error("Apply recommendation error:", error);
      res.status(500).json({ message: "Failed to apply recommendation" });
    }
  });

  // Download optimized resume (placeholder endpoint)
  app.get("/api/resume/download", async (req, res) => {
    try {
      const resumes = await storage.getUserResumes(DEMO_USER_ID);
      const latestResume = resumes.sort((a, b) => 
        new Date(b.uploadedAt!).getTime() - new Date(a.uploadedAt!).getTime()
      )[0];
      
      if (!latestResume) {
        return res.status(404).json({ message: "No resume found" });
      }

      // In production, generate an optimized PDF here
      res.setHeader('Content-Type', 'application/pdf');
      res.setHeader('Content-Disposition', `attachment; filename="optimized_${latestResume.filename}"`);
      res.send(Buffer.from(latestResume.content, 'utf8'));
    } catch (error) {
      console.error("Download resume error:", error);
      res.status(500).json({ message: "Failed to download resume" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

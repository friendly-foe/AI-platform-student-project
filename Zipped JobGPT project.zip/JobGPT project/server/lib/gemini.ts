import { GoogleGenerativeAI } from "@google/generative-ai";

const genAI = new GoogleGenerativeAI("AIzaSyCH9igLLSO-coQf5ldbBFdeMdoNw7hTxTg");
const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });

export interface ResumeAnalysis {
  overallScore: number;
  atsCompatibility: string;
  keywordOptimization: string;
  strengths: string[];
  weaknesses: string[];
  improvements: string[];
  skillsIdentified: Array<{
    name: string;
    level: number;
    category: string;
  }>;
}

export interface CareerRecommendation {
  title: string;
  description: string;
  priority: "high" | "medium" | "low";
  type: "resume" | "skill" | "career";
}

function cleanJsonResponse(text: string): string {
  let cleanText = text.trim();
  
  // Remove markdown code blocks
  cleanText = cleanText.replace(/^```json\s*/i, '').replace(/^```\s*/i, '');
  cleanText = cleanText.replace(/\s*```$/g, '');
  
  // Find JSON object boundaries
  const jsonStart = cleanText.indexOf('{');
  const jsonEnd = cleanText.lastIndexOf('}');
  
  if (jsonStart !== -1 && jsonEnd !== -1 && jsonEnd > jsonStart) {
    cleanText = cleanText.substring(jsonStart, jsonEnd + 1);
  }
  
  return cleanText;
}

export async function analyzeResume(resumeContent: string): Promise<ResumeAnalysis> {
  try {
    const prompt = `
    Analyze the following resume content and provide a comprehensive analysis in JSON format:

    Resume Content:
    ${resumeContent}

    Please analyze and return a JSON object with the following structure:
    {
      "overallScore": number (0-100),
      "atsCompatibility": string ("Excellent", "Good", "Fair", "Poor"),
      "keywordOptimization": string ("Excellent", "Good", "Fair", "Poor"),
      "strengths": array of strings (top 3-5 strengths),
      "weaknesses": array of strings (top 3-5 areas for improvement),
      "improvements": array of strings (specific actionable suggestions),
      "skillsIdentified": array of objects with {name: string, level: number (0-100), category: string}
    }

    Focus on:
    - Technical skills and proficiency levels
    - Professional experience quality
    - Education and certifications
    - Achievement quantification
    - ATS-friendly formatting
    - Industry-relevant keywords
    
    Return only valid JSON, no other text.
    `;

    const result = await model.generateContent(prompt);
    const response = await result.response;
    const text = response.text();
    
    const cleanText = cleanJsonResponse(text);
    const analysisResult = JSON.parse(cleanText);
    
    return {
      overallScore: Math.max(0, Math.min(100, analysisResult.overallScore || 0)),
      atsCompatibility: analysisResult.atsCompatibility || "Fair",
      keywordOptimization: analysisResult.keywordOptimization || "Fair",
      strengths: analysisResult.strengths || [],
      weaknesses: analysisResult.weaknesses || [],
      improvements: analysisResult.improvements || [],
      skillsIdentified: analysisResult.skillsIdentified || [],
    };
  } catch (error) {
    console.error("Error analyzing resume:", error);
    throw new Error("Failed to analyze resume: " + (error as Error).message);
  }
}

export async function generateCareerRecommendations(
  resumeAnalysis: ResumeAnalysis,
  currentPosition: string,
  targetPosition: string
): Promise<CareerRecommendation[]> {
  try {
    const prompt = `
    Based on the following resume analysis and career goals, generate personalized career recommendations:

    Resume Analysis:
    - Overall Score: ${resumeAnalysis.overallScore}/100
    - ATS Compatibility: ${resumeAnalysis.atsCompatibility}
    - Keyword Optimization: ${resumeAnalysis.keywordOptimization}
    - Strengths: ${resumeAnalysis.strengths.join(", ")}
    - Areas for Improvement: ${resumeAnalysis.weaknesses.join(", ")}
    - Skills: ${resumeAnalysis.skillsIdentified.map(s => `${s.name} (${s.level}%)`).join(", ")}

    Current Position: ${currentPosition}
    Target Position: ${targetPosition}

    Generate 3-5 specific, actionable recommendations in JSON format:
    {
      "recommendations": [
        {
          "title": "Recommendation title",
          "description": "Detailed description with specific actions",
          "priority": "high|medium|low",
          "type": "resume|skill|career"
        }
      ]
    }

    Focus on:
    - Resume optimization suggestions
    - Skill development recommendations
    - Career advancement strategies
    - Industry-specific advice
    
    Return only valid JSON, no other text.
    `;

    const result = await model.generateContent(prompt);
    const response = await result.response;
    const text = response.text();
    
    const cleanText = cleanJsonResponse(text);
    const parsed = JSON.parse(cleanText);
    return parsed.recommendations || [];
  } catch (error) {
    console.error("Error generating recommendations:", error);
    throw new Error("Failed to generate recommendations: " + (error as Error).message);
  }
}

export async function generateCareerPath(
  currentPosition: string,
  targetPosition: string,
  skills: Array<{ name: string; level: number }>
): Promise<{
  steps: Array<{
    title: string;
    description: string;
    timeframe: string;
    requirements: string[];
  }>;
  timeline: string;
}> {
  try {
    const skillsList = skills.map(s => `${s.name} (${s.level}%)`).join(", ");
    
    const prompt = `
    Create a detailed career progression path from ${currentPosition} to ${targetPosition}.
    
    Current Skills: ${skillsList}
    
    Generate a career path in JSON format:
    {
      "steps": [
        {
          "title": "Step title",
          "description": "What to focus on in this phase",
          "timeframe": "Duration estimate",
          "requirements": ["specific requirements", "skills to develop", "experiences to gain"]
        }
      ],
      "timeline": "Overall timeline estimate"
    }
    
    Provide 3-5 logical progression steps with realistic timeframes and specific requirements.
    Return only valid JSON, no other text.
    `;

    const result = await model.generateContent(prompt);
    const response = await result.response;
    const text = response.text();
    
    const cleanText = cleanJsonResponse(text);
    const parsed = JSON.parse(cleanText);
    return {
      steps: parsed.steps || [],
      timeline: parsed.timeline || "2-3 years",
    };
  } catch (error) {
    console.error("Error generating career path:", error);
    throw new Error("Failed to generate career path: " + (error as Error).message);
  }
}

export async function calculateJobMatch(
  userSkills: Array<{ name: string; level: number }>,
  jobRequirements: string[]
): Promise<{
  score: number;
  reasons: string[];
}> {
  try {
    const skillsList = userSkills.map(s => `${s.name} (${s.level}%)`).join(", ");
    const requirements = jobRequirements.join(", ");
    
    const prompt = `
    Calculate how well a candidate matches a job based on their skills vs requirements.
    
    Candidate Skills: ${skillsList}
    Job Requirements: ${requirements}
    
    Return a JSON object:
    {
      "score": number (0-100),
      "reasons": ["specific reasons for the match score", "strengths and gaps identified"]
    }
    
    Consider skill relevance, proficiency levels, and coverage of requirements.
    Return only valid JSON, no other text.
    `;

    const result = await model.generateContent(prompt);
    const response = await result.response;
    const text = response.text();
    
    const cleanText = cleanJsonResponse(text);
    const parsed = JSON.parse(cleanText);
    return {
      score: Math.max(0, Math.min(100, parsed.score || 0)),
      reasons: parsed.reasons || [],
    };
  } catch (error) {
    console.error("Error calculating job match:", error);
    throw new Error("Failed to calculate job match: " + (error as Error).message);
  }
}
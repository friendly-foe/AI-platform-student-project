import {
  users,
  resumes,
  skills,
  jobs,
  jobMatches,
  careerPaths,
  recommendations,
  type User,
  type InsertUser,
  type Resume,
  type InsertResume,
  type Skill,
  type InsertSkill,
  type Job,
  type InsertJob,
  type JobMatch,
  type InsertJobMatch,
  type CareerPath,
  type InsertCareerPath,
  type Recommendation,
  type InsertRecommendation,
} from "@shared/schema";

export interface IStorage {
  // Users
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Resumes
  createResume(resume: InsertResume): Promise<Resume>;
  getUserResumes(userId: number): Promise<Resume[]>;
  getResume(id: number): Promise<Resume | undefined>;
  updateResumeAnalysis(id: number, analysis: any, score: number): Promise<Resume>;

  // Skills
  createSkill(skill: InsertSkill): Promise<Skill>;
  getUserSkills(userId: number): Promise<Skill[]>;
  updateSkillLevel(id: number, level: number): Promise<Skill>;

  // Jobs
  createJob(job: InsertJob): Promise<Job>;
  getAllJobs(): Promise<Job[]>;
  getJob(id: number): Promise<Job | undefined>;

  // Job Matches
  createJobMatch(jobMatch: InsertJobMatch): Promise<JobMatch>;
  getUserJobMatches(userId: number): Promise<(JobMatch & { job: Job })[]>;

  // Career Paths
  createCareerPath(careerPath: InsertCareerPath): Promise<CareerPath>;
  getUserCareerPath(userId: number): Promise<CareerPath | undefined>;
  updateCareerPathProgress(id: number, progress: number): Promise<CareerPath>;

  // Recommendations
  createRecommendation(recommendation: InsertRecommendation): Promise<Recommendation>;
  getUserRecommendations(userId: number): Promise<Recommendation[]>;
  markRecommendationApplied(id: number): Promise<Recommendation>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private resumes: Map<number, Resume>;
  private skills: Map<number, Skill>;
  private jobs: Map<number, Job>;
  private jobMatches: Map<number, JobMatch>;
  private careerPaths: Map<number, CareerPath>;
  private recommendations: Map<number, Recommendation>;
  private currentId: number;

  constructor() {
    this.users = new Map();
    this.resumes = new Map();
    this.skills = new Map();
    this.jobs = new Map();
    this.jobMatches = new Map();
    this.careerPaths = new Map();
    this.recommendations = new Map();
    this.currentId = 1;

    // Initialize with sample jobs
    this.initializeSampleJobs();
  }

  private initializeSampleJobs() {
    const sampleJobs = [
      {
        title: "Senior React Developer",
        company: "TechCorp Solutions",
        location: "San Francisco, CA",
        salary: "$120,000 - $150,000",
        description: "We are looking for a Senior React Developer to join our team...",
        requirements: ["React", "JavaScript", "TypeScript", "Node.js"],
        benefits: "Health insurance, 401k, Remote work",
        remote: true,
        active: true,
      },
      {
        title: "Full Stack Engineer",
        company: "StartupXYZ",
        location: "New York, NY",
        salary: "$100,000 - $130,000",
        description: "Join our fast-growing startup as a Full Stack Engineer...",
        requirements: ["React", "Node.js", "MongoDB", "Express"],
        benefits: "Equity, Health insurance, Flexible hours",
        remote: false,
        active: true,
      },
      {
        title: "Frontend Developer",
        company: "Design Studio Inc",
        location: "Austin, TX",
        salary: "$90,000 - $115,000",
        description: "Create beautiful user interfaces with our design team...",
        requirements: ["React", "CSS", "JavaScript", "Figma"],
        benefits: "Health insurance, PTO, Learning budget",
        remote: false,
        active: true,
      },
    ];

    sampleJobs.forEach((job) => {
      const id = this.currentId++;
      const newJob: Job = { ...job, id };
      this.jobs.set(id, newJob);
    });
  }

  // Users
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // Resumes
  async createResume(insertResume: InsertResume): Promise<Resume> {
    const id = this.currentId++;
    const resume: Resume = {
      ...insertResume,
      id,
      analysis: null,
      score: null,
      uploadedAt: new Date(),
    };
    this.resumes.set(id, resume);
    return resume;
  }

  async getUserResumes(userId: number): Promise<Resume[]> {
    return Array.from(this.resumes.values()).filter(
      (resume) => resume.userId === userId,
    );
  }

  async getResume(id: number): Promise<Resume | undefined> {
    return this.resumes.get(id);
  }

  async updateResumeAnalysis(id: number, analysis: any, score: number): Promise<Resume> {
    const resume = this.resumes.get(id);
    if (!resume) throw new Error("Resume not found");
    
    const updatedResume = { ...resume, analysis, score };
    this.resumes.set(id, updatedResume);
    return updatedResume;
  }

  // Skills
  async createSkill(insertSkill: InsertSkill): Promise<Skill> {
    const id = this.currentId++;
    const skill: Skill = { ...insertSkill, id, verified: false };
    this.skills.set(id, skill);
    return skill;
  }

  async getUserSkills(userId: number): Promise<Skill[]> {
    return Array.from(this.skills.values()).filter(
      (skill) => skill.userId === userId,
    );
  }

  async updateSkillLevel(id: number, level: number): Promise<Skill> {
    const skill = this.skills.get(id);
    if (!skill) throw new Error("Skill not found");
    
    const updatedSkill = { ...skill, level };
    this.skills.set(id, updatedSkill);
    return updatedSkill;
  }

  // Jobs
  async createJob(insertJob: InsertJob): Promise<Job> {
    const id = this.currentId++;
    const job: Job = { ...insertJob, id, active: true };
    this.jobs.set(id, job);
    return job;
  }

  async getAllJobs(): Promise<Job[]> {
    return Array.from(this.jobs.values()).filter((job) => job.active);
  }

  async getJob(id: number): Promise<Job | undefined> {
    return this.jobs.get(id);
  }

  // Job Matches
  async createJobMatch(insertJobMatch: InsertJobMatch): Promise<JobMatch> {
    const id = this.currentId++;
    const jobMatch: JobMatch = { ...insertJobMatch, id };
    this.jobMatches.set(id, jobMatch);
    return jobMatch;
  }

  async getUserJobMatches(userId: number): Promise<(JobMatch & { job: Job })[]> {
    const matches = Array.from(this.jobMatches.values()).filter(
      (match) => match.userId === userId,
    );
    
    return matches.map((match) => {
      const job = this.jobs.get(match.jobId);
      if (!job) throw new Error("Job not found");
      return { ...match, job };
    });
  }

  // Career Paths
  async createCareerPath(insertCareerPath: InsertCareerPath): Promise<CareerPath> {
    const id = this.currentId++;
    const careerPath: CareerPath = { ...insertCareerPath, id, progress: 0 };
    this.careerPaths.set(id, careerPath);
    return careerPath;
  }

  async getUserCareerPath(userId: number): Promise<CareerPath | undefined> {
    return Array.from(this.careerPaths.values()).find(
      (path) => path.userId === userId,
    );
  }

  async updateCareerPathProgress(id: number, progress: number): Promise<CareerPath> {
    const careerPath = this.careerPaths.get(id);
    if (!careerPath) throw new Error("Career path not found");
    
    const updatedCareerPath = { ...careerPath, progress };
    this.careerPaths.set(id, updatedCareerPath);
    return updatedCareerPath;
  }

  // Recommendations
  async createRecommendation(insertRecommendation: InsertRecommendation): Promise<Recommendation> {
    const id = this.currentId++;
    const recommendation: Recommendation = { ...insertRecommendation, id, applied: false };
    this.recommendations.set(id, recommendation);
    return recommendation;
  }

  async getUserRecommendations(userId: number): Promise<Recommendation[]> {
    return Array.from(this.recommendations.values()).filter(
      (rec) => rec.userId === userId,
    );
  }

  async markRecommendationApplied(id: number): Promise<Recommendation> {
    const recommendation = this.recommendations.get(id);
    if (!recommendation) throw new Error("Recommendation not found");
    
    const updatedRecommendation = { ...recommendation, applied: true };
    this.recommendations.set(id, updatedRecommendation);
    return updatedRecommendation;
  }
}

export const storage = new MemStorage();

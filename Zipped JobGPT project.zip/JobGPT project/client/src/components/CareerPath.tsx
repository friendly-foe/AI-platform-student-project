import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { CheckCircle, Circle, Target, Clock, TrendingUp } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { apiRequest } from "@/lib/queryClient";

export default function CareerPath() {
  const queryClient = useQueryClient();

  const { data: careerPath, isLoading } = useQuery({
    queryKey: ["/api/career-path"],
  });

  const updateProgressMutation = useMutation({
    mutationFn: async ({ id, progress }: { id: number; progress: number }) => {
      const response = await apiRequest("PATCH", `/api/career-path/${id}/progress`, { progress });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/career-path"] });
    },
  });

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <Skeleton className="h-6 w-48" />
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <Skeleton className="h-24 w-full" />
            <Skeleton className="h-32 w-full" />
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!careerPath) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="text-center">
            <Target className="w-12 h-12 text-primary mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">Career Path Not Found</h3>
            <p className="text-gray-600">Upload a resume to generate your personalized career path.</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  const handleProgressUpdate = (newProgress: number) => {
    updateProgressMutation.mutate({ id: careerPath.id, progress: newProgress });
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Your Career Path</CardTitle>
            <Button variant="ghost" size="sm" className="text-primary hover:text-primary/80">
              <TrendingUp className="mr-2" size={16} />
              View Full Path
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {/* Career Progression Visualization */}
          <div className="relative mb-8">
            <div className="flex items-center justify-between">
              {/* Past */}
              <div className="text-center">
                <div className="w-12 h-12 bg-gray-300 rounded-full flex items-center justify-center mb-2">
                  <CheckCircle className="text-gray-600" size={20} />
                </div>
                <p className="text-xs font-medium text-gray-600">Junior Developer</p>
                <p className="text-xs text-gray-500">2020-2022</p>
              </div>

              {/* Current */}
              <div className="text-center">
                <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center mb-2 ring-4 ring-primary/20">
                  <Target className="text-white" size={20} />
                </div>
                <p className="text-xs font-medium text-gray-900">{careerPath.currentPosition}</p>
                <p className="text-xs text-gray-500">Current</p>
              </div>

              {/* Next */}
              <div className="text-center">
                <div className="w-12 h-12 bg-secondary rounded-full flex items-center justify-center mb-2 opacity-60">
                  <TrendingUp className="text-white" size={20} />
                </div>
                <p className="text-xs font-medium text-gray-600">{careerPath.targetPosition}</p>
                <p className="text-xs text-gray-500">Next 18 months</p>
              </div>

              {/* Future */}
              <div className="text-center">
                <div className="w-12 h-12 bg-gray-200 rounded-full flex items-center justify-center mb-2">
                  <Target className="text-gray-400" size={20} />
                </div>
                <p className="text-xs font-medium text-gray-400">Tech Lead</p>
                <p className="text-xs text-gray-400">3-5 years</p>
              </div>
            </div>

            {/* Progress Line */}
            <div className="absolute top-6 left-6 right-6 h-0.5 bg-gray-200 -z-10">
              <div 
                className="bg-primary h-full transition-all duration-500" 
                style={{ width: `${careerPath.progress}%` }}
              />
            </div>
          </div>

          {/* Overall Progress */}
          <div className="mb-6">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium text-gray-700">Overall Progress</span>
              <span className="text-sm text-gray-600">{careerPath.progress}%</span>
            </div>
            <Progress value={careerPath.progress} className="h-3" />
          </div>

          {/* Timeline */}
          <div className="flex items-center text-sm text-gray-600 mb-4">
            <Clock className="mr-2" size={16} />
            <span>Estimated timeline: {careerPath.timeline}</span>
          </div>
        </CardContent>
      </Card>

      {/* Career Steps */}
      {careerPath.steps && (
        <Card>
          <CardHeader>
            <CardTitle>Next Steps to {careerPath.targetPosition}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {careerPath.steps.map((step: any, index: number) => (
                <div key={index} className="p-4 bg-secondary/5 rounded-lg border border-secondary/10">
                  <div className="flex items-start justify-between mb-2">
                    <h4 className="font-medium text-gray-900">{step.title}</h4>
                    <Badge variant="outline">{step.timeframe}</Badge>
                  </div>
                  <p className="text-sm text-gray-600 mb-3">{step.description}</p>
                  
                  {step.requirements && step.requirements.length > 0 && (
                    <div>
                      <p className="text-xs font-medium text-gray-700 mb-2">Requirements:</p>
                      <ul className="space-y-1">
                        {step.requirements.map((req: string, reqIndex: number) => (
                          <li key={reqIndex} className="flex items-center text-xs text-gray-600">
                            <Circle className="mr-2 text-gray-300" size={8} />
                            {req}
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>
              ))}
            </div>

            {/* Progress Update Buttons */}
            <div className="mt-6 flex gap-2">
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => handleProgressUpdate(Math.max(0, careerPath.progress - 10))}
                disabled={updateProgressMutation.isPending}
              >
                Update Progress -10%
              </Button>
              <Button 
                size="sm"
                onClick={() => handleProgressUpdate(Math.min(100, careerPath.progress + 10))}
                disabled={updateProgressMutation.isPending}
              >
                Update Progress +10%
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

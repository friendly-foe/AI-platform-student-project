import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Lightbulb, Star, AlertTriangle, ArrowRight, Check } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { apiRequest } from "@/lib/queryClient";

export default function AIRecommendations() {
  const queryClient = useQueryClient();

  const { data: recommendations = [], isLoading } = useQuery({
    queryKey: ["/api/recommendations"],
  });

  const applyRecommendationMutation = useMutation({
    mutationFn: async (id: number) => {
      const response = await apiRequest("PATCH", `/api/recommendations/${id}/apply`, {});
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/recommendations"] });
    },
  });

  const getPriorityIcon = (priority: string) => {
    switch (priority) {
      case "high":
        return <Lightbulb className="text-white" size={16} />;
      case "medium":
        return <Star className="text-white" size={16} />;
      case "low":
        return <AlertTriangle className="text-white" size={16} />;
      default:
        return <Lightbulb className="text-white" size={16} />;
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high":
        return "bg-primary";
      case "medium":
        return "bg-success";
      case "low":
        return "bg-warning";
      default:
        return "bg-primary";
    }
  };

  const getGradientColor = (priority: string) => {
    switch (priority) {
      case "high":
        return "from-primary/5 to-secondary/5 border-primary/10";
      case "medium":
        return "from-success/5 to-primary/5 border-success/10";
      case "low":
        return "from-warning/5 to-error/5 border-warning/10";
      default:
        return "from-primary/5 to-secondary/5 border-primary/10";
    }
  };

  const getButtonColor = (priority: string) => {
    switch (priority) {
      case "high":
        return "text-primary hover:text-primary/80";
      case "medium":
        return "text-success hover:text-success/80";
      case "low":
        return "text-warning hover:text-warning/80";
      default:
        return "text-primary hover:text-primary/80";
    }
  };

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <Skeleton className="h-6 w-48" />
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="p-4 border rounded-lg">
                <Skeleton className="h-4 w-64 mb-2" />
                <Skeleton className="h-3 w-full mb-2" />
                <Skeleton className="h-6 w-24" />
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <Lightbulb className="mr-2" size={20} />
          AI-Powered Recommendations
        </CardTitle>
      </CardHeader>
      <CardContent>
        {recommendations.length === 0 ? (
          <div className="text-center py-8">
            <Lightbulb className="w-12 h-12 text-gray-300 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No Recommendations Yet</h3>
            <p className="text-gray-600 text-sm mb-4">Upload a resume to get personalized AI recommendations.</p>
            <Button size="sm">Upload Resume</Button>
          </div>
        ) : (
          <div className="space-y-4">
            {recommendations.map((rec: any) => (
              <div
                key={rec.id}
                className={`flex items-start space-x-4 p-4 bg-gradient-to-r ${getGradientColor(rec.priority)} rounded-lg border`}
              >
                <div className={`w-8 h-8 ${getPriorityColor(rec.priority)} rounded-full flex items-center justify-center flex-shrink-0`}>
                  {rec.applied ? (
                    <Check className="text-white" size={16} />
                  ) : (
                    getPriorityIcon(rec.priority)
                  )}
                </div>
                <div className="flex-1">
                  <div className="flex items-start justify-between mb-1">
                    <h4 className="font-medium text-gray-900">{rec.title}</h4>
                    <div className="flex items-center gap-2">
                      <Badge 
                        variant="outline"
                        className={`text-xs ${rec.priority === 'high' ? 'border-primary/20 text-primary bg-primary/5' : rec.priority === 'medium' ? 'border-success/20 text-success bg-success/5' : 'border-warning/20 text-warning bg-warning/5'}`}
                      >
                        {rec.priority} priority
                      </Badge>
                      <Badge variant="outline" className="text-xs">
                        {rec.type}
                      </Badge>
                    </div>
                  </div>
                  <p className="text-sm text-gray-600 mb-2">{rec.description}</p>
                  {rec.applied ? (
                    <div className="flex items-center text-success text-sm">
                      <Check size={16} className="mr-1" />
                      Applied
                    </div>
                  ) : (
                    <Button
                      variant="ghost"
                      size="sm"
                      className={`${getButtonColor(rec.priority)} h-auto p-0 font-medium text-sm`}
                      onClick={() => applyRecommendationMutation.mutate(rec.id)}
                      disabled={applyRecommendationMutation.isPending}
                    >
                      Apply Suggestion
                      <ArrowRight className="ml-1" size={16} />
                    </Button>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Rocket, Bell, User, BarChart3, Users, Briefcase, Trophy } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import FileUpload from "@/components/FileUpload";
import ResumeAnalysis from "@/components/ResumeAnalysis";
import CareerPath from "@/components/CareerPath";
import SkillsAssessment from "@/components/SkillsAssessment";
import JobMatches from "@/components/JobMatches";
import AIRecommendations from "@/components/AIRecommendations";

export default function Dashboard() {
  const [activeTab, setActiveTab] = useState("dashboard");

  // Fetch user skills for stats
  const { data: skills = [] } = useQuery({
    queryKey: ["/api/skills"],
  });

  // Fetch job matches for stats
  const { data: jobMatches = [] } = useQuery({
    queryKey: ["/api/job-matches"],
  });

  // Fetch resume analysis for stats
  const { data: resumeData } = useQuery({
    queryKey: ["/api/resume/analysis"],
  });

  // Fetch career path for stats
  const { data: careerPath } = useQuery({
    queryKey: ["/api/career-path"],
  });

  const handleDownloadResume = async () => {
    try {
      const response = await fetch("/api/resume/download", {
        credentials: "include",
      });
      
      if (!response.ok) {
        throw new Error("Failed to download resume");
      }
      
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.style.display = "none";
      a.href = url;
      a.download = "optimized_resume.pdf";
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
    } catch (error) {
      console.error("Download failed:", error);
    }
  };

  const resumeScore = resumeData?.analysis?.overallScore || 0;
  const skillsCount = skills.length;
  const jobMatchesCount = jobMatches.length;
  const careerProgress = careerPath?.progress || 0;

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
                <Rocket className="text-white" size={20} />
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-900">CareerCraft</h1>
                <p className="text-xs text-gray-500">AI-Powered Career Development</p>
              </div>
            </div>
            <nav className="hidden md:flex items-center space-x-8">
              <button 
                onClick={() => setActiveTab("dashboard")}
                className={`transition-colors ${activeTab === "dashboard" ? "text-primary" : "text-gray-700 hover:text-primary"}`}
              >
                Dashboard
              </button>
              <button 
                onClick={() => setActiveTab("analysis")}
                className={`transition-colors ${activeTab === "analysis" ? "text-primary" : "text-gray-700 hover:text-primary"}`}
              >
                Resume Analysis
              </button>
              <button 
                onClick={() => setActiveTab("career")}
                className={`transition-colors ${activeTab === "career" ? "text-primary" : "text-gray-700 hover:text-primary"}`}
              >
                Career Paths
              </button>
              <button 
                onClick={() => setActiveTab("jobs")}
                className={`transition-colors ${activeTab === "jobs" ? "text-primary" : "text-gray-700 hover:text-primary"}`}
              >
                Job Matching
              </button>
            </nav>
            <div className="flex items-center space-x-4">
              <Button variant="ghost" size="sm">
                <Bell size={16} />
              </Button>
              <div className="w-8 h-8 bg-gradient-to-r from-primary to-secondary rounded-full flex items-center justify-center">
                <User className="text-white" size={16} />
              </div>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        {activeTab === "dashboard" && (
          <>
            {/* Welcome Section */}
            <div className="mb-8">
              <h2 className="text-3xl font-bold text-gray-900 mb-2">Welcome back, John!</h2>
              <p className="text-gray-600">Let's continue building your career with AI-powered insights and personalized recommendations.</p>
            </div>

            {/* Quick Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600">Resume Score</p>
                      <p className="text-3xl font-bold text-gray-900">{resumeScore}</p>
                    </div>
                    <div className="w-12 h-12 bg-success/10 rounded-lg flex items-center justify-center">
                      <BarChart3 className="text-success" size={24} />
                    </div>
                  </div>
                  <div className="mt-4">
                    <Progress value={resumeScore} className="h-2" />
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600">Skills Identified</p>
                      <p className="text-3xl font-bold text-gray-900">{skillsCount}</p>
                    </div>
                    <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                      <Users className="text-primary" size={24} />
                    </div>
                  </div>
                  <p className="text-sm text-gray-500 mt-2">+3 new skills detected</p>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600">Job Matches</p>
                      <p className="text-3xl font-bold text-gray-900">{jobMatchesCount}</p>
                    </div>
                    <div className="w-12 h-12 bg-secondary/10 rounded-lg flex items-center justify-center">
                      <Briefcase className="text-secondary" size={24} />
                    </div>
                  </div>
                  <p className="text-sm text-gray-500 mt-2">12 new matches today</p>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600">Career Progress</p>
                      <p className="text-3xl font-bold text-gray-900">{careerProgress}%</p>
                    </div>
                    <div className="w-12 h-12 bg-warning/10 rounded-lg flex items-center justify-center">
                      <Trophy className="text-warning" size={24} />
                    </div>
                  </div>
                  <p className="text-sm text-gray-500 mt-2">Senior level target</p>
                </CardContent>
              </Card>
            </div>

            {/* Main Content Grid */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {/* Left Column */}
              <div className="lg:col-span-2 space-y-8">
                <FileUpload />
                <AIRecommendations />
                <CareerPath />
              </div>

              {/* Right Column */}
              <div className="space-y-8">
                <SkillsAssessment />
                <JobMatches />
                
                {/* Career Advice */}
                <Card className="bg-gradient-to-r from-secondary to-primary text-white">
                  <CardContent className="p-6">
                    <div className="flex items-center mb-4">
                      <div className="w-10 h-10 bg-white/20 rounded-lg flex items-center justify-center mr-3">
                        <Trophy className="text-white" size={20} />
                      </div>
                      <h3 className="text-lg font-semibold">Career Tip of the Day</h3>
                    </div>
                    <p className="text-white/90 text-sm mb-4">
                      Networking is crucial for career growth. Consider attending 2-3 tech meetups or online events each month to expand your professional network and stay updated with industry trends.
                    </p>
                    <Button variant="secondary" size="sm" className="bg-white/20 hover:bg-white/30 text-white border-none">
                      Learn More
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="mt-8 flex flex-col sm:flex-row gap-4">
              <Button 
                onClick={handleDownloadResume} 
                className="flex-1 bg-primary hover:bg-primary/90"
                size="lg"
              >
                Download Optimized Resume
              </Button>
              <Button 
                variant="outline" 
                className="flex-1"
                size="lg"
              >
                Schedule Career Coaching
              </Button>
              <Button 
                className="flex-1 bg-secondary hover:bg-secondary/90"
                size="lg"
              >
                Take Full Assessment
              </Button>
            </div>
          </>
        )}

        {activeTab === "analysis" && <ResumeAnalysis />}
        {activeTab === "career" && <CareerPath />}
        {activeTab === "jobs" && <JobMatches />}
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-gray-200 mt-16">
        <div className="container mx-auto px-4 py-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="md:col-span-2">
              <div className="flex items-center space-x-3 mb-4">
                <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                  <Rocket className="text-white" size={16} />
                </div>
                <span className="text-lg font-bold text-gray-900">CareerCraft</span>
              </div>
              <p className="text-gray-600 text-sm max-w-md">
                Empowering professionals with AI-driven career insights, resume optimization, and personalized job matching to accelerate career growth.
              </p>
            </div>
            <div>
              <h4 className="font-semibold text-gray-900 mb-3">Platform</h4>
              <ul className="space-y-2 text-sm text-gray-600">
                <li><button className="hover:text-primary transition-colors">Resume Analysis</button></li>
                <li><button className="hover:text-primary transition-colors">Career Paths</button></li>
                <li><button className="hover:text-primary transition-colors">Job Matching</button></li>
                <li><button className="hover:text-primary transition-colors">Skills Assessment</button></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-gray-900 mb-3">Support</h4>
              <ul className="space-y-2 text-sm text-gray-600">
                <li><button className="hover:text-primary transition-colors">Help Center</button></li>
                <li><button className="hover:text-primary transition-colors">Privacy Policy</button></li>
                <li><button className="hover:text-primary transition-colors">Terms of Service</button></li>
                <li><button className="hover:text-primary transition-colors">Contact Us</button></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-200 mt-8 pt-6 text-center text-sm text-gray-500">
            <p>&copy; 2024 CareerCraft. All rights reserved. Powered by advanced AI technology.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

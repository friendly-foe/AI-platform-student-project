import { pgTable, text, serial, integer, boolean, jsonb, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email"),
  firstName: text("first_name"),
  lastName: text("last_name"),
});

export const resumes = pgTable("resumes", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  filename: text("filename").notNull(),
  content: text("content").notNull(),
  analysis: jsonb("analysis"),
  score: integer("score"),
  uploadedAt: timestamp("uploaded_at").defaultNow(),
});

export const skills = pgTable("skills", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  name: text("name").notNull(),
  level: integer("level").notNull(), // 0-100
  category: text("category").notNull(),
  verified: boolean("verified").default(false),
});

export const jobs = pgTable("jobs", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  company: text("company").notNull(),
  location: text("location").notNull(),
  salary: text("salary"),
  description: text("description").notNull(),
  requirements: jsonb("requirements"),
  benefits: text("benefits"),
  remote: boolean("remote").default(false),
  active: boolean("active").default(true),
});

export const jobMatches = pgTable("job_matches", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  jobId: integer("job_id").notNull(),
  matchScore: integer("match_score").notNull(),
  reasons: jsonb("reasons"),
});

export const careerPaths = pgTable("career_paths", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  currentPosition: text("current_position").notNull(),
  targetPosition: text("target_position").notNull(),
  progress: integer("progress").default(0),
  steps: jsonb("steps"),
  timeline: text("timeline"),
});

export const recommendations = pgTable("recommendations", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  type: text("type").notNull(), // "resume", "skill", "career"
  title: text("title").notNull(),
  description: text("description").notNull(),
  priority: text("priority").notNull(), // "high", "medium", "low"
  applied: boolean("applied").default(false),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  email: true,
  firstName: true,
  lastName: true,
});

export const insertResumeSchema = createInsertSchema(resumes).pick({
  userId: true,
  filename: true,
  content: true,
});

export const insertSkillSchema = createInsertSchema(skills).pick({
  userId: true,
  name: true,
  level: true,
  category: true,
});

export const insertJobSchema = createInsertSchema(jobs).pick({
  title: true,
  company: true,
  location: true,
  salary: true,
  description: true,
  requirements: true,
  benefits: true,
  remote: true,
});

export const insertJobMatchSchema = createInsertSchema(jobMatches).pick({
  userId: true,
  jobId: true,
  matchScore: true,
  reasons: true,
});

export const insertCareerPathSchema = createInsertSchema(careerPaths).pick({
  userId: true,
  currentPosition: true,
  targetPosition: true,
  steps: true,
  timeline: true,
});

export const insertRecommendationSchema = createInsertSchema(recommendations).pick({
  userId: true,
  type: true,
  title: true,
  description: true,
  priority: true,
});

export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type Resume = typeof resumes.$inferSelect;
export type InsertResume = z.infer<typeof insertResumeSchema>;
export type Skill = typeof skills.$inferSelect;
export type InsertSkill = z.infer<typeof insertSkillSchema>;
export type Job = typeof jobs.$inferSelect;
export type InsertJob = z.infer<typeof insertJobSchema>;
export type JobMatch = typeof jobMatches.$inferSelect;
export type InsertJobMatch = z.infer<typeof insertJobMatchSchema>;
export type CareerPath = typeof careerPaths.$inferSelect;
export type InsertCareerPath = z.infer<typeof insertCareerPathSchema>;
export type Recommendation = typeof recommendations.$inferSelect;
export type InsertRecommendation = z.infer<typeof insertRecommendationSchema>;
